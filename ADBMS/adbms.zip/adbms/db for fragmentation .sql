-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 13, 2019 at 09:21 PM
-- Server version: 5.7.23-0ubuntu0.16.04.1
-- PHP Version: 5.6.33-3+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `adbms`
--

-- --------------------------------------------------------

--
-- Table structure for table `sportsleague`
--

CREATE TABLE `sportsleague` (
  `player_id` int(10) DEFAULT NULL,
  `player_name` varchar(50) DEFAULT NULL,
  `team` varchar(50) DEFAULT NULL,
  `player_points` int(10) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sportsleague`
--

INSERT INTO `sportsleague` (`player_id`, `player_name`, `team`, `player_points`, `description`) VALUES
(10, 'abd', 'RCB', 250, 'batsman'),
(20, 'anderson', 'RCB', 120, 'allrounder'),
(30, 'southee', 'RCB', 200, 'bowler'),
(40, 'yadav', 'RCB', 150, 'bowler'),
(50, 'steyn', 'RCB', 150, 'bowler'),
(60, 'chahal', 'RCB', 250, 'bowler'),
(70, 'watson', 'CSK', 250, 'batsman'),
(80, 'rayudu', 'CSK', 200, 'batsman'),
(90, 'raina', 'CSK', 250, 'batsman'),
(100, 'sharama', 'CSK', 150, 'bowler'),
(110, 'russell', 'KKR', 200, 'batsman'),
(120, 'woakes', 'KKR', 125, 'batsman'),
(130, 'dinda', 'KKR', 100, 'bowler'),
(140, 'chahar', 'KKR', 100, 'bowler'),
(150, 'narine', 'KKR', 100, 'allrounder'),
(160, 'malinga', 'MI', 200, 'bowler');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
