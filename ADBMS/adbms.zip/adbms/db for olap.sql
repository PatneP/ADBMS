-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 13, 2019 at 09:22 PM
-- Server version: 5.7.23-0ubuntu0.16.04.1
-- PHP Version: 5.6.33-3+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `adbms`
--

-- --------------------------------------------------------

--
-- Table structure for table `booksales`
--

CREATE TABLE `booksales` (
  `country` varchar(35) DEFAULT NULL,
  `genre` enum('fiction','non-fiction') DEFAULT NULL,
  `year` year(4) DEFAULT NULL,
  `sales` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booksales`
--

INSERT INTO `booksales` (`country`, `genre`, `year`, `sales`) VALUES
('Senegal', 'fiction', 2014, 12234),
('Senegal', 'fiction', 2015, 15647),
('Senegal', 'non-fiction', 2014, 64980),
('Senegal', 'non-fiction', 2015, 78901),
('Paraguay', 'fiction', 2014, 87970),
('Paraguay', 'fiction', 2015, 76940),
('Paraguay', 'non-fiction', 2014, 8760),
('Paraguay', 'non-fiction', 2015, 9030);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
