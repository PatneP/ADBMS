def sort_merge(table1, table1_join_index, table2, table2_join_index):
    a = list(table1)
    b = list(table2)
    if not a or not b:
        return
    table1_copy = sorted(a,key=lambda tup: tup[table1_join_index])
    table2_copy = sorted(b,key=lambda tup: tup[table2_join_index])
    table1_counter = 0
    table2_counter= 0
    while table1_counter < len(table1_copy) and table2_counter < len(table2_copy):
        key = min(table1_copy[table1_counter][table1_join_index],
              table2_copy[table2_counter][table2_join_index])
        table1_group = []
        while table1_counter < len(table1) and key == table1_copy[table1_counter][table1_join_index]:
            table1_group.append(table1_copy[table1_counter])
            table1_counter += 1
        table2_group = []
        while table2_counter < len(table2) and key == table2_copy[table2_counter][table2_join_index]:
            table2_group.append(table2_copy[table2_counter])
            table2_counter += 1
    
        for i in table1_group:
            for o in table2_group:
                yield i + o
                
first_dict = (('A',10),('B',20),('C',30),('D',20),('E',20),('F',30))
second_dict = ((10,'Z'),(20,'Y'),(30,'X'),(40,'V'))
first_dict_join_index = 1
second_dict_join_index = 0
result = sort_merge(first_dict, first_dict_join_index, second_dict, second_dict_join_index)
for value in result:  
    print(value)
